package com.example.touchassist

import android.app.Activity
import android.app.AlertDialog
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

/** تخصيص قايمة المستوى الأعلى (زي iOS): معاينة القايمة + عدد الأيقونات (1-8) + اضغط على أيقونة عشان تغيّرها. */
class TopMenuActivity : Activity() {

    private lateinit var content: LinearLayout

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.layoutDirection = View.LAYOUT_DIRECTION_RTL
        content = LinearLayout(this)
        content.orientation = LinearLayout.VERTICAL
        content.setPadding(dp(16), dp(24), dp(16), dp(32))
        val scroll = ScrollView(this)
        scroll.setBackgroundColor(Color.parseColor("#F2F2F7"))
        scroll.addView(content)
        setContentView(scroll)
    }

    override fun onResume() {
        super.onResume()
        render()
    }

    private fun render() {
        content.removeAllViews()
        val menu = Store.topMenu(this)

        val title = TextView(this)
        title.text = "تخصيص قائمة المستوى الأعلى"
        title.textSize = 22f
        title.setTextColor(Color.BLACK)
        title.setTypeface(title.typeface, Typeface.BOLD)
        content.addView(title)

        // ── معاينة القايمة
        val shown = menu.filter { it != "none" }
        val size = dp(270)
        val panel = FrameLayout(this)
        val bg = GradientDrawable()
        bg.setColor(Color.parseColor("#2B2B2D"))
        bg.cornerRadius = dp(34).toFloat()
        panel.background = bg
        val offs = MenuGeometry.offsets(shown.size, dp(88).toFloat(), dp(84).toFloat())
        val cw = dp(82)
        val ch = dp(74)
        for (i in shown.indices) {
            val cell = LinearLayout(this)
            cell.orientation = LinearLayout.VERTICAL
            cell.gravity = Gravity.CENTER_HORIZONTAL
            cell.addView(IconView(this, shown[i]), LinearLayout.LayoutParams(dp(38), dp(38)))
            val t = TextView(this)
            t.text = Actions.label(this, shown[i])
            t.textSize = 11f
            t.setTextColor(Color.WHITE)
            t.gravity = Gravity.CENTER
            t.maxLines = 2
            cell.addView(t, LinearLayout.LayoutParams(cw, ViewGroup.LayoutParams.WRAP_CONTENT))
            val lp = FrameLayout.LayoutParams(cw, ch)
            lp.gravity = Gravity.TOP or Gravity.START
            lp.leftMargin = (size / 2f + offs[i].x - cw / 2f).toInt()
            lp.topMargin = (size / 2f + offs[i].y - ch / 2f).toInt()
            panel.addView(cell, lp)
        }
        val plp = LinearLayout.LayoutParams(size, size)
        plp.gravity = Gravity.CENTER_HORIZONTAL
        plp.topMargin = dp(16)
        content.addView(panel, plp)

        // ── عدد الأيقونات
        val ctl = LinearLayout(this)
        ctl.orientation = LinearLayout.HORIZONTAL
        ctl.gravity = Gravity.CENTER
        val minus = Button(this)
        minus.text = "−"
        minus.setOnClickListener {
            if (menu.size > 1) {
                menu.removeAt(menu.size - 1)
                Store.setTopMenu(this, menu)
                render()
            }
        }
        val plus = Button(this)
        plus.text = "+"
        plus.setOnClickListener {
            if (menu.size < 8) {
                menu.add("none")
                Store.setTopMenu(this, menu)
                render()
            }
        }
        val cnt = TextView(this)
        cnt.text = "  ${menu.size} أيقونات  "
        cnt.textSize = 16f
        cnt.setTextColor(Color.BLACK)
        ctl.addView(minus)
        ctl.addView(cnt)
        ctl.addView(plus)
        content.addView(ctl)

        val hint = TextView(this)
        hint.text = "اضغط على أيقونة للتغيير:"
        hint.textSize = 13f
        hint.setTextColor(Color.parseColor("#6B6B70"))
        hint.setPadding(dp(4), dp(10), 0, dp(6))
        content.addView(hint)

        // ── مربعات متقطعة لكل أيقونة
        var i = 0
        while (i < menu.size) {
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            for (k in i until minOf(i + 3, menu.size)) {
                val id = menu[k]
                val box = LinearLayout(this)
                box.orientation = LinearLayout.VERTICAL
                box.gravity = Gravity.CENTER
                val d = GradientDrawable()
                d.setColor(Color.WHITE)
                d.cornerRadius = dp(10).toFloat()
                d.setStroke(dp(1), Color.parseColor("#8E8E93"), dp(4).toFloat(), dp(3).toFloat())
                box.background = d
                val iv = IconView(this, id)
                iv.tint = Color.parseColor("#1C1C1E")
                box.addView(iv, LinearLayout.LayoutParams(dp(36), dp(36)))
                val t = TextView(this)
                t.text = Actions.label(this, id)
                t.textSize = 11f
                t.setTextColor(Color.parseColor("#1C1C1E"))
                t.gravity = Gravity.CENTER
                t.maxLines = 2
                box.addView(t, LinearLayout.LayoutParams(dp(92), ViewGroup.LayoutParams.WRAP_CONTENT))
                box.setPadding(0, dp(8), 0, dp(8))
                box.setOnClickListener { choose(id) { picked ->
                    menu[k] = picked
                    Store.setTopMenu(this, menu)
                    render()
                } }
                val blp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                blp.setMargins(dp(4), dp(4), dp(4), dp(4))
                row.addView(box, blp)
            }
            content.addView(row)
            i += 3
        }

        val reset = Button(this)
        reset.text = "إعادة تعيين"
        reset.setOnClickListener {
            Store.setTopMenu(this, Actions.defaultTop)
            render()
        }
        content.addView(reset)
    }

    private fun choose(current: String, onPick: (String) -> Unit) {
        ActionPicker.show(this, "اختر الإجراء", false, current, onPick)
    }
}
